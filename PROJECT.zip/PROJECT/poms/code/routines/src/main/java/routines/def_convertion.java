package routines;
import java.lang.Boolean;


/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class def_convertion {

    /**
     * date_convertion: return the string date in format 'dd-MM-yy'.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("str") input: The string need to be changed.
     * 
     * {example} date_convertion("23-OTT-16") returns "".
     */
    public static String date_convertion(String str) {
    	
    	if (str == null)
    		return null;
    	
    	
    	String[] data = str.split("-");
    	
    	if (data.length > 1) {
    		String mese = data[1];
        	if (mese.equals("GEN")){
        	         data[1]="01";
        	}
        	if (mese.equals("FEB")){
        	         data[1]="02";
        	}
        	if (mese.equals("MAR")){
        	         data[1]="03";
        	}
        	if (mese.equals("APR")){
        	         data[1]="04";
        	}
        	if (mese.equals("MAG")){
        	         data[1]="05";
        	}     
        	if (mese.equals("GIU")){
        	         data[1]="06";
        	}    
        	if (mese.equals("LUG")){
        	         data[1]="07";
        	}
        	if (mese.equals("AGO")){
        	         data[1]="08";
        	}
        	if (mese.equals("SET")){
        	         data[1]="09";
        	}
        	if (mese.equals("OTT")){
        	         data[1]="10";
        	}
        	if (mese.equals("NOV")){
        	         data[1]="11";
        	}
        	if (mese.equals("DIC")){
        	         data[1]="12";
        	}
        	
        	
        	data[2] = "20" + data[2];
        	
        	str =  data[0] + "-" +  data[1] + "-" +  data[2];
    	}
    	else{
    		str = data[0] + "-00-00";
    	}
    	
    	return str;
    }
    
   /**
     * compareData: return the boolean value corresponding the comparison.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("str1") input: string data from source.
     * {param} strinf("str2") input: string data from db
     * 
     */
    
    public static Boolean compareData(String str1,String str2) {
    	if (str1==null)
    		if (str2==null||str2.isEmpty())
    			return true;
    		else return false;
    	
    	if (str2==null)
    		if (str1==null||str1.isEmpty())
    			return true;
    		else return false;
    	
    	return str1.equals(str2);
    }
  
}
